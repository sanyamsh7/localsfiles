# Given a string of n words, help Alex to find out how many times his name
# appears in the string.

string = input("enter the string: ")
name = input("enter the name: ")
occurrence = string.count(name)
print(occurrence)
