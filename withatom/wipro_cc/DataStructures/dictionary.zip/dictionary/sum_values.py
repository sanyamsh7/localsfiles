#Write a program to sum all the values in a dictionary, considering the
#values will be of int type.

my_dict = {2: 30, 3: 40, 4: 50, 5: 60}
print("existing dictionary:", my_dict)
print("sum of all values:", sum(my_dict.values()))
