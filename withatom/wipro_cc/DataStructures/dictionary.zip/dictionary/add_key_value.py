# Write a program to add a key and value to a dictionary.
# Sample Dictionary : {0: 10, 1: 20}
# Expected Result : {0: 10, 1: 20, 2: 30}

my_dict = {0: 10, 1:20}
print("sample dictionary:", my_dict)
my_dict[2] = 30
print("updated dictionary:", my_dict)
