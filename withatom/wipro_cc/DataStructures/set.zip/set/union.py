#Write a program to create an union of sets.
set1 = {3,2,5,4,6,7,8}
set2 = {1,9,3,5,6,7}
print("set1:", set1)
print("set2:", set2)

set = set1.union(set2)

print("union of sets:", set)
