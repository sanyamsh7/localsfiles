#Write a program to find the maximum and minimum value in a set.

set = {3,2,5,2,6,7,8}
print("sample set:", set)

print("maximum in set:", max(set))
print("minimum in set:", min(set))
