#Write a program to print the 4th element from first and 4th element from last in a tuple.

my_tuple = (2,3,4,5,6,5,6,7,4,7,8)
print("original tuple :", my_tuple)
print("fourth element from first:", my_tuple[3])
print("fourth element from last:", my_tuple[-4])
