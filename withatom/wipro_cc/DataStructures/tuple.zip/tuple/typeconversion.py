#Write a program to convert a list into a tuple.

my_list = [3,4,2,5,2,5,8]
print("existing list:", my_list)
print("type:", type(my_list))
my_tuple = tuple(my_list)
print("converted in tuple:", my_tuple)
print("type:", type(my_tuple))
