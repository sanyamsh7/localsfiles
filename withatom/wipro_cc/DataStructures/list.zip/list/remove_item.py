#Write a program to remove the item from a specified index in a list.
my_list = [3,2,4,5,6]
print("existing list:", my_list)
index = 3
print("index to remove:", index)
del my_list[3]
print("list after operation:",my_list)
