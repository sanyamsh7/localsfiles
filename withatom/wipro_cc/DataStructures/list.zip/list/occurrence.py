#Write a program to print the number of occurrences of a specified element in a list.
my_list = [3,4,5,6,7,8,3,4,3,3]
print("list: ", my_list)
print("element is 3")
print("element occurred:",my_list.count(3), "times.")
