#Write a program to append the items of list1 to list2 in the front.
list1 = [1,2,3,4]
list2 = [5,6,7,8,9]
print("list1 is:", list1)
print("list2 is:", list2)
print("append list1 to list2 in front:", list1 + list2)
