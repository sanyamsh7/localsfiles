#Write a program to insert a new item before the second element in an existing list.
my_list = [2,3,4,5,6,7]
print("existing list:", my_list)
item = 1
print("item to insert:", item)
my_list.insert(1, item)
print("list after insertion:", my_list)
