#Write a program to reverse the order of the items in the list.
my_list = [1,2,3,4,5,6,7,8]
print("before reversing the order: ", my_list)
my_list.reverse()
print("after reversing the order: ", my_list)
