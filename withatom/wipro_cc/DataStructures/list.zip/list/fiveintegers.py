#Write a program to create a list of 5 integers and display the list items.
#Access individual elements through index.

my_list = [1,2,3,4,5]

for i in range(5):
    print(my_list[i])
