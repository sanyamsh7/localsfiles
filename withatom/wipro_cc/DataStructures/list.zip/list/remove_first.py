#Write a program to remove the first occurrence of a specified element from a list.
my_list = [4,5,3,5,6,3]
print("existing list:", my_list)
element = 3
print("element to remove:", element)
my_list.remove(3)
print("removing first occurrence of element:", my_list)
