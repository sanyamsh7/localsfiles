#Write a program to append a new item to the end of the list.
my_list = [2,3,5,6,7,8]
print('list before append', my_list)

item = 9

print("item to append", item)

my_list.append(item)

print('list after append', my_list)
