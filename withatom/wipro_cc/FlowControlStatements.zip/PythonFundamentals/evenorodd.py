#Write a program to check if a given number is odd or even.

number = int(input())

if number%2 == 0:
    print("Number is Even")
else:
    print("Number is Odd")
