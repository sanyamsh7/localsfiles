#Write a program to check if the given number is positive, negative or zero

number = int(input())
if number < 0:
    print("Number is Negative")
elif number > 0:
    print("Number is Positive")
else:
    print("Number is zero")
